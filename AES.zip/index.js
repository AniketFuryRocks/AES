var lse = require('./LSEncryption');

//values
var salt = "salt";
var password = "password";
var size = 128;
let data = "Hello World!    ";

//function use case
let key = lse.getKey(password,salt,size);
let encBytes = lse.encrypt(key,data);
let decText = lse.decToText(lse.decrypt(key,encBytes));
console.log(decText);